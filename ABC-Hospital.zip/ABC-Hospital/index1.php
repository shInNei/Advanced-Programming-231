<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/style.css">
    <title>Document</title>
</head>
<body>
<ul class="nav nav-pills nav-justified mb-3" id="ex1" role="tablist" style="width: 40%; margin: auto;">
<li class="nav-item" role="presentation">
    <a
            class="nav-link active"
            id="tab-login"
            data-toggle="pill"
            href="#pills-login"
            role="tab"
            aria-controls="pills-login"
            aria-selected="true"

    >Login</a
    >
</li>
<li class="nav-item" role="presentation">
    <a
            class="nav-link"
            id="tab-register"
            data-toggle="pill"
            href="#pills-register"
            role="tab"
            aria-controls="pills-register"
            aria-selected="false"
    >Register</a
    >
</li>
</body>
</html>